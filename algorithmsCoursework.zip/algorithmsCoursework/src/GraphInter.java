// Ismail-Ridwan jama
//Student id:w1768863

public interface GraphInter {

    public void addEdge(int v , int w);

    public void removeEdge(int v, int w);

    public void createGraphFromFile(String Filename);
    public void hasSink();
    public void hasCycle();




    public void removeSink();




}