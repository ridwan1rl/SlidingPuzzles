// Ismail-Ridwan jama
//Student id:w1768863

public class implamentGraphs {
    public static void main(String[] args) {
        Graph graph = new Graph(40);


        graph.createGraphFromFile("a_40_1.txt");


        //graph.hasSink();
        graph.hasCycle();











    }
}
